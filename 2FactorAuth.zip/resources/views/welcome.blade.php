@extends('layouts.app')

@section('content')
<div class="container">
      <!-- Highlights -->
      <section class="wrapper style1">
			  <div class="container">
				  <div class="row 200%">
					  <section class="4u 12u(narrower)">
						  <div class="box highlight">
							  <a href="login.php"><i class="icon major fa-paper-plane"></i></a>
							  <h3>Login</h3>
							  <p>The first layer of security will ask for your Login details; that's the Account No and Password. If you don't have the password contact admin, to activate your account for online banking transactions.</p>
						  </div>
					  </section>
					  <section class="4u 12u(narrower)">
						  <div class="box highlight">
							  <i class="icon major fa-pencil"></i>
							  <h3>2FA</h3>
							  <p>The 2nd factor authenication layer will generate a random number and send it to you via your mobile number that you set up the account with.</p>
						  </div>
					  </section>
					  <section class="4u 12u(narrower)">
						  <div class="box highlight">
							  <i class="icon major fa-wrench"></i>
							  <h3>Transaction</h3>
							  <p>After verifying the 2FA, you'll then be able to perform a secured transaction with us.</p>
						  </div>
					  </section>
				  </div>
			  </div>
		  </section>

	  <!-- Gigantic Heading -->
		  <section class="wrapper style2">
			  <div class="container">
				  <header class="major">
					  <h2>MicroFinance Bank is interested in keeping it's customers safe from unauthorized attacks</h2>
					  <p>Thanks for Banking with US.</p>
				  </header>
			  </div>
		  </section>

	  <!-- Posts -->
		  <section class="wrapper style1"></section>

	  <!-- CTA -->
		  <section id="cta" class="wrapper style3"></section>

</div>
@endsection
