@extends('layouts.app')

@section('content')
<div class="container">
<p>This Project is to take us Second level of Banking Security Operates.</p>
				  <p>Thanks!!!</p>
</div>
@endsection
