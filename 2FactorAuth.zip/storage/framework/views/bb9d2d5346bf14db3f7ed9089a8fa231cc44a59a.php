

<?php $__env->startSection('content'); ?>
<div class="container">
<p>This Project is to take us Second level of Banking Security Operates.</p>
				  <p>Thanks!!!</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2FactorAuth\resources\views/about.blade.php ENDPATH**/ ?>